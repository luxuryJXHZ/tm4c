#ifndef  __BSP_LED_H__
#define  __BSP_LED_H__

#include <stdint.h>

void bsp_InitLed(void);
void Led3_SetOn(void);
void Led3_SetOff(void);
void Led3_Toggle(void);

#endif

